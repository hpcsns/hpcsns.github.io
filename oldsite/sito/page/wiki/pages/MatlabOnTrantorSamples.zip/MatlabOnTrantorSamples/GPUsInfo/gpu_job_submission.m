%% Creates a 'cluster' object and sets the resources required by the job
cluster = parcluster('Trantor');
cluster.AdditionalProperties.QueueName = 'q07daneel';
cluster.AdditionalProperties.ProcsPerNode = 2;
cluster.AdditionalProperties.MemPerNode = 1;
cluster.AdditionalProperties.GpusPerNode = 1;

%% Submits the job to the cluster
job = batch(cluster, @gpusInfo, 1, {}, 'Pool', 1, 'AutoAddClientPath', false);

%% Wait for the job to finish
wait(job, 'finished')

%% Retrieves the results and deletes the job
results = fetchOutputs(job);
delete(job)
display(results{1})
