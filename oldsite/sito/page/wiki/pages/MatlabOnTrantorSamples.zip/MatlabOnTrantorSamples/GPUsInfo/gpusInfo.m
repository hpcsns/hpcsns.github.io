function result = gpusInfo()
result = gpuDeviceTable();
