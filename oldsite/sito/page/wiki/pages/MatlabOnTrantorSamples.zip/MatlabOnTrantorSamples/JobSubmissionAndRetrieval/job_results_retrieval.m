%% Creates an object representing the finished job
JOB_ID = 1; % Set this variable to the Job ID displayed on the first column of the Job Monitor panel
cluster = parcluster('Trantor');
job = findJob(cluster, 'ID', JOB_ID);

%% Retrieves the results and deletes the job
results = fetchOutputs(job);
delete(job);
display(results{1})
