%% Resources to be reserved for the job
workers = 4; % Number of worker processes to employ.
processes = workers + 1; % MATLAB spawns an additional process to control and coordinate the computation.
queueName = 'q07helicon'; % Name of the submission queue.
maxCoresPerNode = 8; % Maximum number of CPU cores to reserve on each compute node.
coresPerNode = min(processes, maxCoresPerNode); % CPU cores to reserve on each compute node.
numberOfNodes = ceil(processes/coresPerNode); % Number of compute nodes to employ.
memPerProcess = 2; % How much RAM memory to assign to each process, expressed in GB.
memPerNode = memPerProcess * coresPerNode; % How much RAM memory to reserve on each node, expressed in GB.
gpusPerNode = 0; % This computation don't make use of GPUs

%% Creates a 'cluster' object and sets the resources required by the job
cluster = parcluster('Trantor');
cluster.AdditionalProperties.QueueName = queueName;
cluster.AdditionalProperties.ProcsPerNode = coresPerNode;
cluster.AdditionalProperties.MemPerNode = memPerNode;
cluster.AdditionalProperties.GpusPerNode = gpusPerNode;

%% Submits the job to the cluster
batch(cluster, @findPrimeNumbers, 1, {1000000}, 'Pool', workers, 'AutoAddClientPath', false);
