% Trivial parallel algorithm to find all the prime numbers in the range [1,n].
% The parameter n must be a positive integer.
function primes = findPrimeNumbers(n)

% --- PARALLEL SECTION ---
primes_flags = false(n,1);
parfor i = 2:n
    divisor = 0;
    for j = 2:floor(sqrt(i))
        if mod(i, j) == 0
            divisor = j;
            break
        end
    end
    if divisor == 0
        primes_flags(i) = true;
    end
end
% ------------------------

num_primes = sum(primes_flags);
primes = zeros(num_primes, 1);
counter = 0;
for k = 2:n
    if primes_flags(k)
        counter = counter + 1;
        primes(counter) = k;
    end
end
